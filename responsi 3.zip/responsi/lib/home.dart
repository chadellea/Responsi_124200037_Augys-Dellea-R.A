import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:responsi/base_network.dart';
import 'package:responsi/matches_model.dart';
import 'package:responsi/detail_matches_model.dart';


class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          appBar: AppBar(
            title: Text("Piala Dunia 2022"),
            centerTitle: true,
            automaticallyImplyLeading: true,
            backgroundColor: Colors.blue,
            leading: InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: Icon(
                Icons.arrow_back_ios,
                color: Colors.white,
              ),
            ),
          ),
          body: Container(
            padding: EdgeInsets.all(8),
            child: FutureBuilder(
              future: BaseNetwork.get("matches"),
              builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
                if (snapshot.hasError) {
                  return _buildErrorSection();
                }
                if (snapshot.hasData) {
                  MatchesModel matchesModel = MatchesModel.fromJson(snapshot.data);
                  return _buildSuccessSection(matchesModel);
                }
                return _buildLoadingSection();
              },
            ),
          ),
        )
    );
  }

  Widget _buildErrorSection() {
    return Text("Error");
  }

  Widget _buildLoadingSection() {
    return Center(
      child: CircularProgressIndicator(),
    );
  }

  Widget _buildSuccessSection(MatchesModel data) {
    return ListView.builder(
        itemCount: 48,
        itemBuilder: (BuildContext context, int index) {
          // final Movies? movies = data.movies?[index];
          return InkWell(
              onTap: () {
                // Navigator.push(context, MaterialPageRoute(
                //     builder: (context) => MovieDetail(movie: movies)));
              },
              child: Text(data.homeTeam!.name!)
          );
        }
    );
  }
}